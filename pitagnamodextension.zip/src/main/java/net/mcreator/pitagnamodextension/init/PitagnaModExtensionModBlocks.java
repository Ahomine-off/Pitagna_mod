/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pitagnamodextension.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.pitagnamodextension.block.PitagnaDimensionPortalBlock;
import net.mcreator.pitagnamodextension.block.ChestBlock;
import net.mcreator.pitagnamodextension.PitagnaModExtensionMod;

import java.util.function.Function;

public class PitagnaModExtensionModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(PitagnaModExtensionMod.MODID);
	public static final DeferredBlock<Block> PITAGNA_DIMENSION_PORTAL = register("pitagna_dimension_portal", PitagnaDimensionPortalBlock::new);
	public static final DeferredBlock<Block> CHEST = register("chest", ChestBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}