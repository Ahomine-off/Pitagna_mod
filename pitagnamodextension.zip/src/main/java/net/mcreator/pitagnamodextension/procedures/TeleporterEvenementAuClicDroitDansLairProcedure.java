package net.mcreator.pitagnamodextension.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.Minecraft;

import net.mcreator.pitagnamodextension.network.PitagnaModExtensionModVariables;

public class TeleporterEvenementAuClicDroitDansLairProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		{
			PitagnaModExtensionModVariables.PlayerVariables _vars = entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES);
			_vars.x = x + Mth.nextDouble(RandomSource.create(), 5000, 72817);
			_vars.syncPlayerVariables(entity);
		}
		{
			PitagnaModExtensionModVariables.PlayerVariables _vars = entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES);
			_vars.z = z + Mth.nextDouble(RandomSource.create(), 5000, 862785);
			_vars.syncPlayerVariables(entity);
		}
		world.setBlock(BlockPos.containing(entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).x, y, entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).z), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).x, y + 1, entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).z), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).x, y + 2, entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).z), Blocks.OAK_PLANKS.defaultBlockState(), 3);
		{
			Entity _ent = entity;
			_ent.teleportTo(entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).x, y, entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).z);
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).x, y, entity.getData(PitagnaModExtensionModVariables.PLAYER_VARIABLES).z, _ent.getYRot(), _ent.getXRot());
		}
		if (!(getEntityGameType(entity) == GameType.CREATIVE)) {
			if (world instanceof ServerLevel _level) {
				itemstack.hurtAndBreak(1, _level, null, _stkprov -> {
				});
			}
		}
	}

	private static GameType getEntityGameType(Entity entity) {
		if (entity instanceof ServerPlayer serverPlayer) {
			return serverPlayer.gameMode.getGameModeForPlayer();
		} else if (entity instanceof Player player && player.level().isClientSide()) {
			PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().getId());
			if (playerInfo != null)
				return playerInfo.getGameMode();
		}
		return null;
	}
}