/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pitagnamod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.pitagnamod.item.inventory.BackpackInventoryCapability;
import net.mcreator.pitagnamod.item.PitagnacoalItem;
import net.mcreator.pitagnamod.item.PitagnaIngotItem;
import net.mcreator.pitagnamod.item.BackpackItem;
import net.mcreator.pitagnamod.PitagnaModMod;

import java.util.function.Function;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class PitagnaModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(PitagnaModMod.MODID);
	public static final DeferredItem<Item> BACKPACK = register("backpack", BackpackItem::new);
	public static final DeferredItem<Item> PITAGNA_INGOT = register("pitagna_ingot", PitagnaIngotItem::new);
	public static final DeferredItem<Item> PITAGNACOAL = register("pitagnacoal", PitagnacoalItem::new);
	public static final DeferredItem<Item> PITAGNA_LUKY_BLOCK = block(PitagnaModModBlocks.PITAGNA_LUKY_BLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new BackpackInventoryCapability(stack), BACKPACK.get());
	}
}