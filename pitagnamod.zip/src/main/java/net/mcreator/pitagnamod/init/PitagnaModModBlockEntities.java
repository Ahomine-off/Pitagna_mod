/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pitagnamod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.items.wrapper.SidedInvWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.pitagnamod.block.entity.PitagnaLukyBlockBlockEntity;
import net.mcreator.pitagnamod.PitagnaModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class PitagnaModModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, PitagnaModMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PitagnaLukyBlockBlockEntity>> PITAGNA_LUKY_BLOCK = register("pitagna_luky_block", PitagnaModModBlocks.PITAGNA_LUKY_BLOCK, PitagnaLukyBlockBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> DeferredHolder<BlockEntityType<?>, BlockEntityType<T>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> new BlockEntityType(supplier, block.get()));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, PITAGNA_LUKY_BLOCK.get(), SidedInvWrapper::new);
	}
}