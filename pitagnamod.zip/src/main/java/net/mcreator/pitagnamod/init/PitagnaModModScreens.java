/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pitagnamod.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.pitagnamod.client.gui.SortguiScreen;
import net.mcreator.pitagnamod.client.gui.PitagnomeScreen;
import net.mcreator.pitagnamod.client.gui.LuckyBlockGuiScreen;
import net.mcreator.pitagnamod.client.gui.ChatomeScreen;
import net.mcreator.pitagnamod.client.gui.BackpackguiScreen;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class PitagnaModModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(PitagnaModModMenus.BACKPACKGUI.get(), BackpackguiScreen::new);
		event.register(PitagnaModModMenus.CHATOME.get(), ChatomeScreen::new);
		event.register(PitagnaModModMenus.SORTGUI.get(), SortguiScreen::new);
		event.register(PitagnaModModMenus.PITAGNOME.get(), PitagnomeScreen::new);
		event.register(PitagnaModModMenus.LUCKY_BLOCK_GUI.get(), LuckyBlockGuiScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}