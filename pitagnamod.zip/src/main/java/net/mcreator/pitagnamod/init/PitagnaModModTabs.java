/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pitagnamod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.pitagnamod.PitagnaModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class PitagnaModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PitagnaModMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> PITAGNA_MOD = REGISTRY.register("pitagna_mod",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.pitagna_mod.pitagna_mod")).icon(() -> new ItemStack(PitagnaModModItems.PITAGNA_INGOT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(PitagnaModModItems.BACKPACK.get());
				tabData.accept(PitagnaModModItems.PITAGNA_INGOT.get());
				tabData.accept(PitagnaModModItems.PITAGNACOAL.get());
				tabData.accept(PitagnaModModBlocks.PITAGNA_LUKY_BLOCK.get().asItem());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(PitagnaModModItems.BACKPACK.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(PitagnaModModItems.PITAGNA_INGOT.get());
			tabData.accept(PitagnaModModItems.PITAGNACOAL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(PitagnaModModBlocks.PITAGNA_LUKY_BLOCK.get().asItem());
		}
	}
}