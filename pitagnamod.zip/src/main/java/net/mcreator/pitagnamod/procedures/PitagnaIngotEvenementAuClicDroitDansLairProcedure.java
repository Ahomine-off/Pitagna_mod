package net.mcreator.pitagnamod.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.pitagnamod.network.PitagnaModModVariables;

public class PitagnaIngotEvenementAuClicDroitDansLairProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			PitagnaModModVariables.PlayerVariables _vars = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES);
			_vars.Pitagna_power = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).Pitagna_power + 1;
			_vars.syncPlayerVariables(entity);
		}
	}
}