package net.mcreator.pitagnamod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.pitagnamod.network.PitagnaModModVariables;

public class ChatomesortProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).Pitagna_power >= 2) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = EntityType.CAT.spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement(0, 0, 0);
				}
			}
			{
				PitagnaModModVariables.PlayerVariables _vars = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES);
				_vars.Pitagna_power = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).Pitagna_power - 2;
				_vars.syncPlayerVariables(entity);
			}
			if (entity instanceof Player _player)
				_player.closeContainer();
		}
	}
}