package net.mcreator.pitagnamod.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.commands.CommandSourceStack;

import net.mcreator.pitagnamod.network.PitagnaModModVariables;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class PitagnapowercommandprocedureProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		{
			PitagnaModModVariables.PlayerVariables _vars = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES);
			_vars.Pitagna_power = DoubleArgumentType.getDouble(arguments, "name");
			_vars.syncPlayerVariables(entity);
		}
	}
}