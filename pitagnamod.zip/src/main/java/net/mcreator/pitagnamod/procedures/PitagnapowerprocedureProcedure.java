package net.mcreator.pitagnamod.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.pitagnamod.network.PitagnaModModVariables;
import net.mcreator.pitagnamod.PitagnaModMod;

public class PitagnapowerprocedureProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		PitagnaModMod.LOGGER.info(entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).Pitagna_power);
	}
}