package net.mcreator.pitagnamod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.pitagnamod.network.PitagnaModModVariables;
import net.mcreator.pitagnamod.init.PitagnaModModItems;
import net.mcreator.pitagnamod.init.PitagnaModModBlocks;

public class PitagnaLuckyBlockProcedureProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		PitagnaModModVariables.WorldVariables.get(world).lucky = Mth.nextDouble(RandomSource.create(), 1, 100);
		PitagnaModModVariables.WorldVariables.get(world).syncData(world);
		world.destroyBlock(BlockPos.containing(x, y, z), false);
		if (entity instanceof Player _player)
			_player.closeContainer();
		if (PitagnaModModVariables.WorldVariables.get(world).lucky <= 30 && PitagnaModModVariables.WorldVariables.get(world).lucky >= 20) {
			for (int index0 = 0; index0 < (int) Mth.nextDouble(RandomSource.create(), 1, 25); index0++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(PitagnaModModItems.PITAGNA_INGOT.get()));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			for (int index1 = 0; index1 < (int) Mth.nextDouble(RandomSource.create(), 0, 2); index1++) {
				{
					PitagnaModModVariables.PlayerVariables _vars = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES);
					_vars.Pitagna_power = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).Pitagna_power + 1;
					_vars.syncPlayerVariables(entity);
				}
			}
		} else if (PitagnaModModVariables.WorldVariables.get(world).lucky < 19 && PitagnaModModVariables.WorldVariables.get(world).lucky > 1) {
			for (int index2 = 0; index2 < (int) Mth.nextDouble(RandomSource.create(), 1, 3); index2++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(PitagnaModModBlocks.PITAGNA_LUKY_BLOCK.get()));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
		} else if (PitagnaModModVariables.WorldVariables.get(world).lucky >= 31 && PitagnaModModVariables.WorldVariables.get(world).lucky <= 49) {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 5, Level.ExplosionInteraction.TNT);
		} else if (PitagnaModModVariables.WorldVariables.get(world).lucky >= 50 && PitagnaModModVariables.WorldVariables.get(world).lucky <= 69) {
			{
				PitagnaModModVariables.PlayerVariables _vars = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES);
				_vars.Pitagna_power = 0;
				_vars.syncPlayerVariables(entity);
			}
		} else if (PitagnaModModVariables.WorldVariables.get(world).lucky >= 70 && PitagnaModModVariables.WorldVariables.get(world).lucky <= 85) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = EntityType.WITHER.spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
				}
			}
		} else {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = EntityType.CAT.spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
				}
			}
		}
		PitagnaModModVariables.WorldVariables.get(world).lucky = 0;
		PitagnaModModVariables.WorldVariables.get(world).syncData(world);
	}
}