package net.mcreator.pitagnamod.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.pitagnamod.network.PitagnaModModVariables;
import net.mcreator.pitagnamod.init.PitagnaModModMenus;
import net.mcreator.pitagnamod.init.PitagnaModModItems;

public class PitagnomesortProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).Pitagna_power >= 3) {
			if (entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).number_pitagnome < 64) {
				{
					PitagnaModModVariables.PlayerVariables _vars = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES);
					_vars.number_pitagnome = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).number_pitagnome + 1;
					_vars.syncPlayerVariables(entity);
				}
				if (entity instanceof Player _player && _player.containerMenu instanceof PitagnaModModMenus.MenuAccessor _menu) {
					ItemStack _setstack = new ItemStack(PitagnaModModItems.PITAGNA_INGOT.get()).copy();
					_setstack.setCount((int) entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).number_pitagnome);
					_menu.getSlots().get(0).set(_setstack);
					_player.containerMenu.broadcastChanges();
				}
				{
					PitagnaModModVariables.PlayerVariables _vars = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES);
					_vars.Pitagna_power = entity.getData(PitagnaModModVariables.PLAYER_VARIABLES).Pitagna_power - 3;
					_vars.syncPlayerVariables(entity);
				}
			}
		}
	}
}