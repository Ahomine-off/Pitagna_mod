package net.mcreator.pitagnamod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PitagnacoalItem extends Item {
	public PitagnacoalItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).fireResistant());
	}
}