package net.mcreator.pitagnamod.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;

import net.mcreator.pitagnamod.procedures.PitagnaIngotEvenementAuClicDroitDansLairProcedure;

public class PitagnaIngotItem extends Item {
	public PitagnaIngotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC));
	}

	@Override
	public void onCraftedBy(ItemStack itemstack, Level world, Player entity) {
		super.onCraftedBy(itemstack, world, entity);
		PitagnaIngotEvenementAuClicDroitDansLairProcedure.execute(entity);
	}
}